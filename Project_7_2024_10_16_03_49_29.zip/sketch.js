
    function setup() {
      createCanvas(400, 400);
var militarytimeofday = 900;
	var rainchance = generaterainchance(militarytimeofday);
	print(rainchance);
  }

function generaterainchance(w) {
	var newWeight = w * 0.02;
	return newWeight;
}

function draw() {
background(0, 100, 200);
fill('green')
  rect(0, 300, 400, 100)
	for (var x = 0; x < width + 110; x += 50) {
		clouds(x, 83);
        bolt(x, 100)
	}
}
function bolt(x,y) {
  
  push(); 
translate(x, y);
    scale(1.4) 
  rotate(HALF_PI)
   fill(200, 200, 0)
  quad(-50, 10, 70, 90, 10, 60, 102, 120)
  pop(); 
}

function clouds(x, y) {

  push();
translate(x, y);
noStroke();
fill(80);
circle(-45, -55, 60); 
circle(-30, -60, 40)
circle(-14, -65, 50)
  pop();
}