function setup() {
  createCanvas(700, 800);
  colorMode(RGB, 255);
  ellipseMode(RADIUS);
  frameRate(100);
}
var Rect1 = 320;
var Rect2 = 490; 
var RectW = 50;
var RectH = 90;
var Cx = 550;
var Cy = 530;
var radius = 30;
var power = false;
var channel = 0;
var displayText = true;
var x = 150;
var y = 530;

function draw() {
  background(180);
  square(290, 310, 100)
  strokeWeight(12);
  fill(0, 100, 240);
  stroke(0, 20, 110);
  ellipse(350, 530, 300, 100);
  stroke(0, 10, 90);
  fill(0, 50, 150);
  rect(Rect1, Rect2, RectW, RectH);
  ellipse(Cx, Cy, radius, radius);
  ellipse(x, y, radius, radius);
  
  if (!power) {
    fill(0, 0, 0);
  } else {
    if (channel == 0) {
      fill(0, 100, 240);
    } else if (channel == 5) {
      fill(0, 0, 125);
    }
  }
  stroke(0, 0, 100);
  ellipse(340, 210, 300, 175);
  if (keyIsPressed) {
    if (key == " ") {
      if (dist(mouseX, mouseY, x, y) <= radius) {
        ellipse(340, 210, 200, 170);
        ellipse(340, 210, 150, 120);
        ellipse(340, 210, 100, 70);
}
}
}
}

function mouseClicked() {
  if (mouseX >= Rect1 && mouseX <= Rect1 + RectW && mouseY >= Rect2 && mouseY <= Rect2 + RectH) {
    power = !power;
  }
  
  if (dist(mouseX, mouseY, Cx, Cy) <= radius) {
    if (channel < 2) {
      channel++;
    } else {
      channel = 0;
    }
  }
}
