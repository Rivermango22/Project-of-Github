
var x = []; 

function setup() {
	createCanvas(400, 400);
	
  stroke(50);
	for (var i = 0; i < 8000; i++) {
		x[i] = random(-2000, 400); 
	}
}
function draw() {
background('lightblue');
  
 fill('orange')
      rect(0, 300, 400, 100)
  fill('brown')
  rect(50, 120, 50, 200)
   rect(190, 120, 50, 200)
  rect(325, 140, 50, 180)
  fill(500, 200, 0)
  ellipse(75, 120, 180, 250)
  ellipse(220, 120, 180, 250)
  ellipse(350, 120, 180, 250)

	for (var i = 0; i < x.length; i++) {
		x[i] +=3;
		var y = i * 2;
        var z= i * 1.97;
		rect(x[i], z, 12, 12, 0.2, 100);
        ellipse(x[i], y, 10, 1, 100)
     }
}